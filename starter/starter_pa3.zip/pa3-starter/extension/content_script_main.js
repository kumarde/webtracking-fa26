// PA3 ad blocker: content script that uses the "MAIN" world (meaning, JS
// objects and variables are shared with the page).
//
// TODO: Implement any logic that requires access to MAIN world here.
