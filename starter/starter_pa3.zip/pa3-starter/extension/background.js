// PA3 ad blocker: background.js as a service worker
//
// TODO: Implement your code below, which reads rule files and sets up
// appropriate filters and data access for content scripts.

const RULE_FILES = ["rules/level1.json", "rules/level2.json", "rules/level3.json"];

async function install() {
    // TODO: Implement install logic here, and when done, set "ready" in
    // storage.
    console.log("The extension is installed!");
    await chrome.storage.local.set({ready: true});
}

chrome.runtime.onInstalled.addListener(() => {
    install().catch((error) => console.error("PA3: rule install failed:", error))
});
