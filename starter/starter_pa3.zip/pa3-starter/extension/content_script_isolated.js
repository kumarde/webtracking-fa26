// PA3 ad blocker: content script that uses an isolated world (JS objects are
// not shared with the page) but can still access the DOM. 
//
// Note (may or may not be useful to you): This script runs before
// content_main.js because it is listed first in manifest.json. 
