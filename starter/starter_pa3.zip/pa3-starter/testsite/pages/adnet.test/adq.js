(function () {
  var queued = (window.adq && window.adq.cmd) || [];
  var cmd = [];
  cmd.push = function (f) { f(); return 0; };
  window.adq = {
    loaded: true,
    cmd: cmd,
    display: function (id) {
      var el = document.getElementById(id);
      if (!el) return;
      var img = document.createElement("img");
      img.src = "http://adnet.test/creative/zazora.svg";
      img.width = 300;
      img.height = 250;
      el.appendChild(img);
    }
  };
  for (var i = 0; i < queued.length; i++) queued[i]();
})();
