#!/usr/bin/env python3
"""This server creates a "fake web" for PA3 to serve local pages via domains.
Run it with:

    python3 server.py

It serves every *.test site from the pages/ folder next to this file, acting
as a proxy for Chrome for those sites only.
"""

import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

PAGES = Path(__file__).resolve().parent / "pages"
PORT = 8190
DEMO_PAGES = ["http://news.test/level1/", "http://news.test/level2/", "http://news.test/level3/"]

PAC = """function FindProxyForURL(url, host) {
  if (dnsDomainIs(host, ".test")) return "PROXY 127.0.0.1:%d";
  return "DIRECT";
}
"""

CHROME_FLAGS = [
    "--proxy-pac-url=http://127.0.0.1:{port}/proxy.pac",
    "--disable-features=HttpsUpgrades,HttpsFirstBalancedModeAutoEnable",
    "--no-first-run",
]

TYPES = {
    ".html": "text/html; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".json": "application/json",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".gif": "image/gif",
    ".jpg": "image/jpeg",
}


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/proxy.pac":
            pac = PAC % self.server.server_port
            return self.reply(200, pac.encode(), "application/x-ns-proxy-autoconfig")
        url = urlsplit(self.path)
        host = url.hostname or ""
        if url.scheme != "http" or not host.endswith(".test"):
            return self.reply(403, b"This server only serves http://*.test sites.\n")
        file = (PAGES / host / url.path.lstrip("/")).resolve()
        if file.is_dir() and not url.path.endswith("/"):
            # /level1 -> /level1/
            query = "?" + url.query if url.query else ""
            return self.reply(302, location="http://%s%s/%s" % (host, url.path, query))
        if file.is_dir():
            file = file / "index.html"
        if not file.is_file() or PAGES not in file.parents:
            return self.reply(404, b"Not found.\n")
        self.reply(200, file.read_bytes(), TYPES.get(file.suffix, "application/octet-stream"))

    def do_POST(self):
        # Tracker beacons, just accept them and send 204
        self.rfile.read(int(self.headers.get("Content-Length") or 0))
        self.reply(204)

    def reply(self, status, body=b"", content_type="text/plain; charset=utf-8", location=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")  # every reload asks again
        self.send_header("Access-Control-Allow-Origin", "*")
        if location:
            self.send_header("Location", location)
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args):
        pass  # keep the terminal quiet: use DevTools' Network tab to see requests


class Server(ThreadingHTTPServer):
    def handle_error(self, request, client_address):
        # Handle when Chrome often hangs up mid-reply (a closed tab, a reload.. etc.)
        if not isinstance(sys.exc_info()[1], ConnectionError):
            super().handle_error(request, client_address)


def chrome_command(port, platform=sys.platform):
    """The command that starts Chrome with appropriate settings on macOS,
    Windows, or Linux"""
    flags = " ".join(flag.format(port=port) for flag in CHROME_FLAGS)
    if platform == "darwin":
        return 'open -na "Google Chrome" --args --user-data-dir=$HOME/pa3-chrome-profile ' + flags
    if platform.startswith("win"):
        return (r'"C:\Program Files\Google\Chrome\Application\chrome.exe"'
                r" --user-data-dir=%USERPROFILE%\pa3-chrome-profile " + flags)
    return "google-chrome --user-data-dir=$HOME/pa3-chrome-profile " + flags


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else PORT
    try:
        server = Server(("127.0.0.1", port), Handler)
    except OSError:
        sys.exit("Port %d is in use. Is server.py already running in another window?\n"
                 "To use another port: python3 server.py %d" % (port, port + 1))
    port = server.server_port
    print("The fake web proxy is running at http://127.0.0.1:%d" % port)
    print("You can leave this server open while you test your extension. Ctrl-C will stop the server.")
    print()
    print("Follow the next three steps:")
    print()
    print("1. Start Chrome with its own profile and using this server for .test sites:")
    print()
    print("   " + chrome_command(port))
    print()
    print("The command above should start Chrome with the appropriate settings, or at least give you a starting point for how to start it on your setup.")
    if sys.platform.startswith("win"):
        print("   (Paste it into Command Prompt, not PowerShell.)")
    elif sys.platform != "darwin":
        print("   (Use chromium instead of google-chrome if that is what you have.)")
    print()
    print("2. In that Chrome instance, open chrome://extensions, turn on Developer mode,")
    print("   click Load unpacked and choose the folder holding your extension code.")
    print()
    print("3. Open the demo pages and explore how your extension interacts with the pages. Type the full http:// address:")
    print()
    for url in DEMO_PAGES:
        print("   " + url)
    print(flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
